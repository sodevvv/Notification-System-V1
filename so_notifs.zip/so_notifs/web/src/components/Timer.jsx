import { useEffect, useRef } from "react"

export default function Timer({ duration, onFinish }) {
  const timeoutRef = useRef(null)
  const onFinishRef = useRef(onFinish)

  useEffect(() => {
    onFinishRef.current = onFinish
  }, [onFinish])

  useEffect(() => {
    timeoutRef.current = setTimeout(() => {
      onFinishRef.current()
    }, duration)

    return () => clearTimeout(timeoutRef.current)
  }, [duration])

  return (
    <div className="alert-timer">
      <div
        className="timer"
        style={{ animationDuration: `${duration}ms` }}
      />
    </div>
  )
}
