import { useEffect, useRef, useState } from "react";
import Timer from "./Timer";

function AnnounceNotification({ id, job, jobLogo, type, AnnounceTypeColor, message, numero, leaving, duration, onFinish }) {
  const messageRef = useRef(null);
  const [containerHeight, setContainerHeight] = useState(180);
  useEffect(() => {
    if (messageRef.current) {
      const messageBottom =
        messageRef.current.offsetTop +
        messageRef.current.scrollHeight +
        20;
      setContainerHeight(Math.max(180, messageBottom));
    }


    

  }, [message]);

  return (
    <div
      className={`announce-notification ${leaving ? "fade-out" : ""}`}
      style={{ height: `${containerHeight}px` }}
    >
      <img src={jobLogo} alt="" className="announce-logo" />
      <div className="annonce-job-name">{job}</div>
      <div className="announce-type"style={{backgroundColor: AnnounceTypeColor}}>{type}</div>
      

      <div className="announce-message" ref={messageRef}>
        {message}
      </div>

      <div className="announce-numero"style={{backgroundColor: AnnounceTypeColor}}>{numero}</div>
      <div className="announce-icon">
        <i className="fa-solid fa-phone-flip"style={{color: AnnounceTypeColor}}></i>
      </div>

      <Timer duration={duration} onFinish={() => onFinish(id)} />
    </div>
  );
}
export default AnnounceNotification;