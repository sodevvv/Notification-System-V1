import { useState, useEffect } from "react"
import "./App.css"
import newNotificationSound from "./assets/new-notification.mp3"
import AnnounceComp from "./components/announce"
import Timer from "./components/Timer"

function App() {
  const [notifications, setNotifications] = useState([])
  const [alerts, setAlerts] = useState([])
  const [announces, setAnnounces] = useState([])
  const [alertPos, setAlertPos] = useState({ top: 500, left: 30 })

  const spawnSound = () => {
    const audio = new Audio(newNotificationSound)
    audio.volume = 0.1
    audio.play().catch(() => {})
  }


  const addNotification = (icon, text, color) => {
    const id = crypto.randomUUID()

    setNotifications(prev => [
      ...prev,
      {
        id,
        icon,
        text,
        color,
        duration: 3000,
        leaving: false
      }
    ])

    spawnSound()
  }

  const removeClassic = (id) => {
    setNotifications(prev =>
      prev.map(n =>
        n.id === id ? { ...n, leaving: true } : n
      )
    )

    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id))
    }, 300)
  }


  const removeAlert = (id) => {
    setAlerts(prev =>
      prev.map(a =>
        a.id === id ? { ...a, leaving: true } : a
      )
    )

    setTimeout(() => {
      setAlerts(prev => prev.filter(a => a.id !== id))
    }, 300)
  }

    const removeAnnounce = (id) => {
      setAnnounces(prev =>
        prev.map(a =>
          a.id === id ? { ...a, leaving: true } : a
        )
      );

      setTimeout(() => {
        setAnnounces(prev => prev.filter(a => a.id !== id));
      }, 300);
    };


  const respondAlert = (accepted) => {
    if (alerts.length === 0) return

    const alert = alerts[0]

    fetch(`https://so_notifs/alertResponse`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        accepted,
        job: alert.job,
        text: alert.text,
        position: alertPos,
        coords: alert.coords, 

      })
    })

    removeAlert(alert.id)
  }


  useEffect(() => {
    const handler = (event) => {
      const data = event.data

      if (data.action === "addNotification-classic") {
        addNotification(data.icon, data.text, data.color)
      }

      if (data.action === "addNotification-alert") {
        const id = crypto.randomUUID()

        if (data.pos) setAlertPos(data.pos)
        spawnSound()

        setAlerts(prev => [
          {
            id,
            leaving: false,
            duration: 7000,
            job: data.job,
            text: data.text,
            location: data.location,
            distance: data.distance,
            coords: data.coords
          },
          ...prev
        ])
      }

      if (data.action === "alert-key") {
        respondAlert(data.key === "Y")
      }


      if (data.action === "addNotification-announce") {
        const id = crypto.randomUUID()

        if (data.pos) setAlertPos(data.pos)
        spawnSound()

        setAnnounces(prev => [
          ...prev, 
          {
            id,
            leaving: false,
            duration: 7000,
            job: data.job,
            jobLogo: data.jobLogo,
            type: data.type,
            AnnounceTypeColor: data.announeTypeColor,
            message: data.message,
            numero: data.numero
          }
        ]);
      }
    }

    window.addEventListener("message", handler)
    return () => window.removeEventListener("message", handler)
  }, [alerts])


  return (
    <div className="container">

      <div className="classic-notification-stack">
        {notifications.map(notif => (
          <div
            key={notif.id}
            className={`classic-notification ${notif.leaving ? "fade-out" : ""}`}
          >
            <div
              className="classic-notification-icon"
              style={{ color: notif.color }}
            >
              <i className={notif.icon}></i>
            </div>

            <div className="classic-notification-text">
              {notif.text}
            </div>

            <Timer
              key={notif.id}
              duration={notif.duration}
              onFinish={() => removeClassic(notif.id)}
            />
          </div>
        ))}
      </div>

      <div
        className="alert-notification-stack"
        style={{
          top: `${alertPos.top}px`,
          left: `${alertPos.left}px`,
        }}
      >
        {alerts.map(alert => (
          <div
            key={alert.id}
            className={`alert-notification ${alert.leaving ? "fade-out" : ""}`}
          >
            <div className="aler-info">
              <div className="job-alert">{alert.job}</div>

              <div className="keys-circle">
                <div className="accept" onClick={() => respondAlert(true)}>Y</div>
                <div className="refuse" onClick={() => respondAlert(false)}>N</div>
              </div>
            </div>
            <div className="alert">
                  <div className="alert-icon">
                    <i className="fa-solid fa-info"></i>
                  </div>

                  <div className="alert-content">
                    <div className="alert-name">{alert.text}</div>
                    <div className="alert-location-name">{alert.location}</div>
                    <div className="alert-location-m">{alert.distance}</div>
                  </div>

                  <div className="alert-localisation-icon">
                    <i className="fa-solid fa-location-dot"></i>
                  </div>
                </div>
              <Timer
                    key={alert.id}  
                    duration={alert.duration}
                    onFinish={() => removeAlert(alert.id)}
                  />

          </div>
        ))}

        <div className="announce-notification-stack">
          {announces.map(announce => (
            <AnnounceComp
              key={announce.id}
              id={announce.id}
              job={announce.job}
              jobLogo={announce.jobLogo}
              type={announce.type}
              AnnounceTypeColor={announce.AnnounceTypeColor}
              message={announce.message}
              numero={announce.numero}
              leaving={announce.leaving}
              duration={announce.duration}
              onFinish={removeAnnounce}

            />
          ))}
        </div>


      </div>

      
    </div>
  )
}

export default App
