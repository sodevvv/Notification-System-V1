
RegisterServerEvent(GetCurrentResourceName() .. ':SendAnnounceJob')
AddEventHandler(GetCurrentResourceName() .. ':SendAnnounceJob', function(jobName, message, numero)
    local xPlayers = ESX.GetPlayers()
    local jobLogo = "https://i.imgur.com/0o2m4hA.png"

    for _, playerId in ipairs(xPlayers) do
        local xPlayer = ESX.GetPlayerFromId(playerId)

        if xPlayer and xPlayer.job and xPlayer.job.name == jobName then
            TriggerClientEvent("so_notifs:SendAnnounce", playerId, jobName:upper(),
            jobLogo,
            "Annonce", 
            "rgba(6, 133, 38, 1)", 
            message,
            numero 
            )
        end
    end
end)


RegisterServerEvent(GetCurrentResourceName() .. ':SendDefaultNotification')
AddEventHandler(GetCurrentResourceName() .. ':SendDefaultNotification', function(source, icon, message, color, duration)
        TriggerClientEvent('so_notifs:SendNotification', source, {
            icon = icon,    
            text = message,
            color = color,
            duration = duration
        })
end)