fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'So'
version '1.0.2'

ui_page 'web/dist/index.html'

files {
    'web/dist/index.html',
    'web/dist/assets/*.js',
    'web/dist/assets/*.css',
    'web/dist/assets/*.mp3',
    'web/dist/uwucafe.png',
}

client_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'client.lua',
}