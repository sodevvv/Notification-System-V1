
RegisterNetEvent("so_notifs:SendAnnounce")
AddEventHandler("so_notifs:SendAnnounce", function(job, jobLogo, type, announeTypeColor, message, numero)
    AddAnnounce(job, jobLogo, type, announeTypeColor, message, numero)
end)


RegisterNetEvent("so_notifs:SendAlert")
AddEventHandler("so_notifs:SendAlert", function(job, jobLogo, type, announeTypeColor, message, numero)
    AddAlert({
        job = job,
        jobLogo = jobLogo,
        type = type, 
        announeTypeColor = announeTypeColor,
        message = message,
        numero = numero
    })
end)

RegisterNetEvent("so_notifs:SendNotification")
AddEventHandler("so_notifs:SendNotification", function(data)
    AddNotificationBasic(data.icon, data.text, data.color)
end)



function AddNotificationBasic(icon, text, color)
    SendNUIMessage({
        action = "addNotification-classic",
        icon = icon,
        text = text,
        color = color
    })
end
function AddAlert(data)
    SendNUIMessage({
        action = "addNotification-alert",

        job = data.job or "LSPD",
        text = data.text or "Appel de renfort (Inconnu)",
        location = data.location or "Unknown",
        distance = data.distance or "0m",
        coords = data.coords or { 0, 0, 0 },
        pos = {
            top = data.top or 500,
            left = data.left or 30
        }
    })
  
end

function AddAnnounce(job, jobLogo, type, announeTypeColor, message, numero)
    SendNUIMessage({
        action = "addNotification-announce",
        job = job,
        jobLogo = jobLogo,
        type = type, 
        announeTypeColor = announeTypeColor,
        message = message,
        numero = numero
    })
end



RegisterCommand("alert", function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    local alertCoords = vec3(250.11273193359, -1183.4860839844, 29.57382774353)
    local dist = #(coords - alertCoords)
    local distText = string.format("%.1fm", dist)

    exports.so_notifs:AddAlert({
        job = "LSPD",
        text = "Vente de drogues",
        location = "Great Ocean Highway",
        coords = { alertCoords.x, alertCoords.y, alertCoords.z },
        distance = distText,
        top = 500,
        left = 30
    })
end)
RegisterCommand("notify", function(source, args)
    local icon = args[1] .. " " .. args[2] or "fa-solid fa-check"
    local name = args[3] or "Notification"
    local color = args[4] or "white"
    exports.so_notifs:AddNotificationBasic(icon, name, color)

end, false)

RegisterCommand("CreateAnnounce", function(source, args)
    local job = args[1] or "UWU CAFE"
    local jobLogo = "uwucafe.png"
    local type = args[2] or "Annonce"
    local announeTypeColor = args[3] or "rgba(6, 133, 38, 1)"
    local message = args[4] or "Le Uwu Cafe est ouvert !"
    local numero = args[5] or "1234"
    exports.so_notifs:AddAnnounce(job, jobLogo, type, announeTypeColor, message, numero)
end, false)


RegisterNUICallback("alertResponse", function(data, cb)
    if data.accepted  and data.coords then
            local x, y, z = table.unpack(data.coords)
            SetNewWaypoint(x, y)
        else

        cb("ok")
    end
end)
RegisterCommand("+alert_accept", function()
    SendNUIMessage({
        action = "alert-key",
        key = "Y"
    })
end)

RegisterCommand("+alert_refuse", function()
    SendNUIMessage({
        action = "alert-key",
        key = "N"
    })
end)



RegisterKeyMapping("+alert_accept", "Alert - Accepter", "keyboard", "Y")
RegisterKeyMapping("+alert_refuse", "Alert - Refuser", "keyboard", "N")

exports("AddAnnounce", AddAnnounce)
exports("AddAlert", AddAlert)
exports("AddNotificationBasic", AddNotificationBasic)